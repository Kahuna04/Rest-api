"""Cement core backend module."""

VERSION = (2, 8, 2, 'final', 0)  # pragma: nocover

# global hooks/handlers (DEPRECATED)
__handlers__ = {}  # pragma: nocover
__hooks__ = {}  # pragma: nocover
